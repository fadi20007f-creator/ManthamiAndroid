package com.example.manthami

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class Task(var text: String, var done: Boolean = false)
data class Category(val id: String, var name: String, var emoji: String, val tasks: MutableList<Task>)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var back: Button
    private lateinit var addCategory: Button
    private var current: Category? = null
    private val prefs by lazy { getSharedPreferences("planner", Context.MODE_PRIVATE) }
    private val categories = mutableListOf<Category>()

    private val teal = Color.rgb(15,118,110)
    private val bg = Color.rgb(244,245,247)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        back = Button(this).apply {
            text = "→"; textSize = 18f; visibility = View.GONE
            setOnClickListener { showHome() }
        }
        addCategory = Button(this).apply {
            text = "＋"; textSize = 20f
            setOnClickListener { addCategoryDialog() }
        }
        val spacer = Space(this)
        header.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        title = TextView(this).apply { textSize=21f; setTypeface(null, Typeface.BOLD); gravity=Gravity.CENTER }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(addCategory, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(header)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(14),dp(14),dp(20)) }
        subtitle = TextView(this).apply { textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,0,0,dp(12)) }
        content.addView(subtitle)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        this.content = content
    }

    private lateinit var content: LinearLayout

    private fun showHome() {
        current=null; back.visibility=View.GONE; addCategory.visibility=View.VISIBLE
        title.text="منظّم مهامي"; subtitle.text="اختار قسم حتى تدخل إلى مجموعة مهامه"
        content.removeViews(1, maxOf(0, content.childCount-1))
        val grid = GridLayout(this).apply { columnCount=2; useDefaultMargins=false }
        categories.forEach { c ->
            val done=c.tasks.count{it.done}
            val card=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(15),dp(16),dp(15))
                setBackgroundColor(Color.WHITE); elevation=dp(3).toFloat()
                setOnClickListener { open(c) }
            }
            val e=TextView(this).apply{text=c.emoji;textSize=34f}
            val n=TextView(this).apply{text=c.name;textSize=18f;setTypeface(null,Typeface.BOLD);setPadding(0,dp(7),0,dp(5))}
            val co=TextView(this).apply{text="$done من ${c.tasks.size} مكتملة";textSize=13f;setTextColor(Color.GRAY)}
            card.addView(e);card.addView(n);card.addView(co)
            val p=GridLayout.LayoutParams().apply{width=0;height=dp(140);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(5),dp(5),dp(5),dp(5))}
            grid.addView(card,p)
        }
        content.addView(grid)
    }

    private fun open(c: Category) {
        current=c; back.visibility=View.VISIBLE; addCategory.visibility=View.GONE
        title.text="${c.emoji} ${c.name}"; subtitle.text="مجموعة مهام ${c.name}"
        content.removeViews(1, maxOf(0, content.childCount-1))
        val add=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val input=EditText(this).apply{hint="اكتب مهمة جديدة...";setSingleLine(true);textSize=16f}
        val btn=Button(this).apply{text="إضافة";setTextColor(Color.WHITE);setBackgroundColor(teal)}
        add.addView(input,LinearLayout.LayoutParams(0,dp(54),1f));add.addView(btn,LinearLayout.LayoutParams(dp(105),dp(54)))
        content.addView(add)
        btn.setOnClickListener{addTask(input)}
        input.setOnEditorActionListener{_,_,_->addTask(input);true}
        val clear=Button(this).apply{text="حذف المنجزة";setOnClickListener{c.tasks.removeAll{it.done};save();open(c)}}
        content.addView(clear)
        renderTasks(c)
    }

    private fun addTask(input: EditText) {
        val s=input.text.toString().trim(); if(s.isEmpty())return
        current?.tasks?.add(Task(s));save();input.text.clear();open(current!!)
    }

    private fun renderTasks(c: Category) {
        if(c.tasks.isEmpty()){
            content.addView(TextView(this).apply{text="ماكو مهام حالياً.\nأضف أول مهمة من الأعلى.";textSize=16f;gravity=Gravity.CENTER;padding=dp(30)})
            return
        }
        c.tasks.forEachIndexed { i,t ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(5),dp(5),dp(5));setBackgroundColor(Color.WHITE)}
            val check=CheckBox(this).apply{isChecked=t.done;setOnCheckedChangeListener{_,v->t.done=v;save();open(c)}}
            val text=TextView(this).apply{text=t.text;textSize=16f;setPadding(dp(7),0,dp(7),0);if(t.done)paintFlags=paintFlags or 16}
            val del=Button(this).apply{text="×";setOnClickListener{c.tasks.removeAt(i);save();open(c)}}
            row.addView(check,LinearLayout.LayoutParams(dp(55),dp(58)));row.addView(text,LinearLayout.LayoutParams(0,dp(58),1f));row.addView(del,LinearLayout.LayoutParams(dp(55),dp(58)))
            val lp=LinearLayout.LayoutParams(-1,dp(60));lp.setMargins(0,dp(5),0,dp(4));content.addView(row,lp)
        }
    }

    private fun addCategoryDialog() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),0,dp(18),0)}
        val name=EditText(this).apply{hint="اسم القسم"}
        val emoji=EditText(this).apply{hint="رمز مثل 📚";setSingleLine(true)}
        box.addView(name);box.addView(emoji)
        AlertDialog.Builder(this).setTitle("إضافة قسم").setView(box)
            .setNegativeButton("إلغاء",null).setPositiveButton("إضافة"){_,_->
                val n=name.text.toString().trim();if(n.isNotEmpty()){categories.add(Category("c${System.currentTimeMillis()}",n,emoji.text.toString().ifEmpty{"📌"},mutableListOf()));save();showHome()}
            }.show()
    }

    private fun save(){
        val a=JSONArray();categories.forEach{c->
            val o=JSONObject().put("id",c.id).put("name",c.name).put("emoji",c.emoji);val ts=JSONArray()
            c.tasks.forEach{ts.put(JSONObject().put("text",it.text).put("done",it.done))};o.put("tasks",ts);a.put(o)
        };prefs.edit().putString("data",a.toString()).apply()
    }
    private fun load(){
        val raw=prefs.getString("data",null)
        if(raw==null){
            categories.addAll(listOf(
                Category("study","الدراسة","📚",mutableListOf(Task("مراجعة الرياضيات"),Task("حل الواجب"),Task("قراءة الدرس"))),
                Category("home","البيت","🏠",mutableListOf(Task("ترتيب الغرفة"),Task("تنظيف البيت"))),
                Category("money","الاقتصاد","💰",mutableListOf(Task("تسجيل المصاريف"),Task("متابعة الميزانية"))),
                Category("sport","الرياضة","🏃",mutableListOf(Task("المشي 30 دقيقة"),Task("تمارين الصباح"))),
                Category("shopping","المشتريات","🛒",mutableListOf(Task("شراء ملابس"),Task("شراء مواد غذائية"))),
                Category("personal","شخصي","👤",mutableListOf(Task("قراءة كتاب"),Task("تنظيم الوقت")))
            ));save();return
        }
        val a=JSONArray(raw);for(i in 0 until a.length()){val o=a.getJSONObject(i);val ts=mutableListOf<Task>();val arr=o.getJSONArray("tasks");for(j in 0 until arr.length()){val t=arr.getJSONObject(j);ts.add(Task(t.getString("text"),t.getBoolean("done")))};categories.add(Category(o.getString("id"),o.getString("name"),o.getString("emoji"),ts))}
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun maxOf(a:Int,b:Int)=if(a>b)a else b
}
